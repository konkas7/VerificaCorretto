﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VITA_VERIFICA
{
    internal class Registro
    {
        private const int maxvoti = 999;
        private int lenght;
        private Verifica[] _ver = new Verifica[maxvoti];




        public Verifica[] verifi
        {
            get
            {
                Verifica[] p = new Verifica[lenght];
                for (int i = 0; i < lenght; i++)
                {
                    p[i] = _ver[i];
                }
                return p;
            }
            set { _ver = value; }
        }

        public string Media()
        {
            float med = 0;
            int count = 0;
            for (int i = 0; i < _ver.Length; i++)
            {
                if (_ver[i] != null)
                {
                    med = med + float.Parse(_ver[i].Voto);
                    count++;
                }
                
            }

            med = med / count;
            string a = med.ToString();
            return a;
        }








        public void Aggiungi(Verifica p)
        {
            if (lenght == maxvoti)
            {
                throw new Exception("Impossibile aggiungere, dimensione massima registro raggiunta");
            }

            if (p != null)
            {
                _ver[lenght] = p;
                ++lenght;
            }
            else
                throw new Exception("Inserire un valore valido");
        }

        public void Modifica(string a, string b, string c, string d)
        {
            for (int i = 0; i < lenght; i++)
            {
                if (a == _ver[i].Id)
                {
                    _ver[i].Materia = b;
                    _ver[i].Voto = c;
                    _ver[i].Data = d;
                    return;
                }
            }
        }

        



        public void Rimuovi(string p)
        {



            


            for (int i = 0; i < lenght; i++)
            {
                if (p == _ver[i].Id)
                {
                    _ver[i] = null;
                }
            }

        }
    }
}
