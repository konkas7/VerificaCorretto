﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VITA_VERIFICA
{
    public partial class Form1 : Form
    {
        int xxx = 0;

        private Registro reg;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {




            


        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            /*reg = new Registro();
            Verifica ver1 = new Verifica(textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text);

            reg.Aggiungi(ver1);
            MessageBox.Show("Verifica aggiunta");
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";*/
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

            /*if (listino.FocusedItem == null) return;
            int listIndex = listino.FocusedItem.Index;
            MessageBox.Show(Convert.ToString(listIndex));*/

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] intestazione = new string[] { "ID", "MATERIA", "VOTO", "DATA" };

            for (int i = 0; i < intestazione.Length; i++)
            {
                listino.Columns.Add(intestazione[i]);
            }
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void label5_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click_3(object sender, EventArgs e)
        {
            MessageBox.Show(reg.Media());
        }

        private void buttonVisualizza_Click(object sender, EventArgs e)
        {
            Verifica[] verifiche = reg.verifi;

            for (int i = 0; i < verifiche.Length; i++)
            {
                ListViewItem riga = new ListViewItem(verifiche[i].ToString().Split(';'));
                listino.Items.Add(riga);
            }
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            reg.Rimuovi(textBox5.Text);
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            reg.Modifica(textBox5.Text, textBox6.Text, textBox7.Text, textBox8.Text);
        }

        private void buttonCreaCarrello_Click(object sender, EventArgs e)
        {
            reg = new Registro();
            Verifica ver1 = new Verifica(textBox1.Text, textBox2.Text, textBox3.Text, textBox4.Text);
            if (int.Parse(textBox1.Text) <= xxx)
            {
                throw new Exception("Questo id è già stato inserito precedentemente");
            }

            reg.Aggiungi(ver1);
            MessageBox.Show("Verifica aggiunta");
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";

            xxx++;

            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}

