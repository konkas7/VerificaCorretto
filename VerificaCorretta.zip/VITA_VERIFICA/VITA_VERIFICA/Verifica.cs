﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VITA_VERIFICA
{
    public class Verifica
    {
        private string _id, _materia, _data;
        private string _voto;

        public string Voto
        {
            get
            {
                return _voto;
            }
            set
            {
                _voto = value;

            }
        }

        public string Id
        {
            get
            {
                return _id;
            }
            set
            {
                if (value != null)
                    _id = value;
                else
                    throw new Exception("Inserire un id valido");
            }
        }

        public string Materia
        {
            get
            {
                return _materia;
            }
            set
            {
                if (value != null)
                    _materia = value;
                else
                    throw new Exception("Inserire una materia valida");
            }
        }

        public string Data
        {
            get
            {
                return _data;
            }
            set
            {
                if (value != null)
                    _data = value;
                else
                    throw new Exception("Inserire una data valida");
            }
        }




        public Verifica(string id, string materia, string data, string voto)
        {
            Id = id;
            Materia = materia;
            Voto = voto;
            Data = data;
        }






        /*Equals

        public bool Equals(Prodotto p)
        {
            if (p == null) return false;

            if (this == p) return true;

            return (this.Id == p.Id);
        }*/

        public override string ToString()
        {
            return Id + ";" + Materia + ";" + Voto + ";" + Data;
        }
    }
}
